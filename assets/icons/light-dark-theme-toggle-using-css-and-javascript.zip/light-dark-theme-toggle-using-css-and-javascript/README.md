# Light/Dark Theme Toggle using CSS and Javascript

A Pen created on CodePen.

Original URL: [https://codepen.io/Umer_Farooq/pen/eYJgKGN](https://codepen.io/Umer_Farooq/pen/eYJgKGN).

